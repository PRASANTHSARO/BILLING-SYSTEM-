package metroRecharge;

public class metroDetails {
	String metro, smartCardID;
	public void setMetro(String metro) {	
		this.metro = metro;
	}
	public String getMetro() {
		return metro;
	}
	public void setID(String ID) {
		this.smartCardID = ID;
	}
	public String getID() {
		return smartCardID;
	}
}
