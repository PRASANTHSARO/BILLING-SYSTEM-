package DTHRecharge;

public class DTHDetails {
	String Biller, subscriberID;
	public void setBiller(String Biller) {
		
		this.Biller = Biller;
	}
	public String getBiller() {
		return Biller;
	}
	public void setID(String ID) {
		this.subscriberID = ID;
	}
	public String getID() {
		return subscriberID;
	}
}
