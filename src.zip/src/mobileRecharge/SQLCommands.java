package mobileRecharge;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SQLCommands{
	
	void sql(String Username, String Password) throws SQLException{
		SQLCommands query = new SQLCommands();
		
		
	}
	
}
