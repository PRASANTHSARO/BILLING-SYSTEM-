/**
 * 
 */
/**
 * @author rohith vishwa
 *
 */
module bankingSystem {
	requires java.sql;
}